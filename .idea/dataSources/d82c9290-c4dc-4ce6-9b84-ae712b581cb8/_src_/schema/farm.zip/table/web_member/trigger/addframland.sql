CREATE TRIGGER farm.addframland
AFTER INSERT ON farm.web_member
FOR EACH ROW
  begin
DECLARE n int;
set n=15;
while  n>0  do
   insert into web_framlandtype (uid,landtype) values(new.id,n);
set n=n-1;
end while;
end;
