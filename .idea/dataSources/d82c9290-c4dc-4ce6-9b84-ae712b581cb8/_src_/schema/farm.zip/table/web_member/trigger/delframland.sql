CREATE TRIGGER farm.delframland
AFTER DELETE ON farm.web_member
FOR EACH ROW
  begin
  delete  from web_framlandtype where uid=old.id;
end;
