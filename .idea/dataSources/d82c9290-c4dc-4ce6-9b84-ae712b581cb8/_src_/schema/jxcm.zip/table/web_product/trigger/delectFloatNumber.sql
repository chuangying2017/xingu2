CREATE TRIGGER jxcm.delectFloatNumber
AFTER DELETE ON jxcm.web_product
FOR EACH ROW
  begin
DELETE FROM web_floatnumber where `pid`=old.id;
end;
