CREATE TRIGGER jxcm.insertFloatNumber
AFTER INSERT ON jxcm.web_product
FOR EACH ROW
  begin
insert into web_floatnumber(`pid`) values(new.id);
end;
