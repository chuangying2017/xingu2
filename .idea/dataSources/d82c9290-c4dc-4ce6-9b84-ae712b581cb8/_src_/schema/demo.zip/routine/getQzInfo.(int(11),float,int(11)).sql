CREATE PROCEDURE demo.getQzInfo(IN `_uid` INT, INOUT `_fanDian` FLOAT, INOUT `_parentId` INT)
  begin

	declare done int default 0;
	declare cur cursor for
	select fanDian, parentId from ssc_members where `uid`=_uid;
	declare continue HANDLER for not found set done = 1;

	open cur;
		fetch cur into _fanDian, _parentId;
	close cur;
	
	-- select 1, _fanDian, _parentId;
end;
