CREATE PROCEDURE demo.setCoin(IN `_coin`      FLOAT, IN `_fcoin` FLOAT, IN `_uid` INT, IN `_liqType` INT,
                              IN `_type`      INT, IN `_info` VARCHAR(255), IN `_extfield0` INT,
                              IN `_extfield1` VARCHAR(255), IN `_extfield2` VARCHAR(255))
  begin
	
	-- 当前时间
	declare currentTime int default unix_timestamp();
	declare _userCoin float;

	-- select _coin, _fcoin, _liqType, _info;
	if _coin is null then
		set _coin=0;
	end if;
	if _fcoin is null then
		set _fcoin=0;
	end if;
	-- 更新用户表
	update ssc_members set coin = coin + _coin, fcoin = fcoin + _fcoin where `uid` = _uid;
	select coin into _userCoin from ssc_members where `uid`=_uid;
	
	-- 添加资金流动日志
	insert into ssc_coin_log(coin, fcoin, userCoin, `uid`, actionTime, liqType, `type`, info, extfield0, extfield1, extfield2) values(_coin, _fcoin, _userCoin, _uid, currentTime, _liqType, _type, _info, _extfield0, _extfield1, _extfield2);
	
	-- select coin, fcoin from ssc_members where `uid`=_uid;

end;
