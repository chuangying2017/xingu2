CREATE PROCEDURE xy_yule.isFirstRechargeCom(IN `_uid` INT, OUT flag INT)
  begin
	
	declare dateTime int default unix_timestamp(curdate());
	select id into flag from xy_member_recharge where rechargeTime>dateTime and `uid`=_uid;
	
end;
