CREATE PROCEDURE xy_yule.setCoin(IN `_coin`      FLOAT, IN `_fcoin` FLOAT, IN `_uid` INT, IN `_liqType` INT,
                                 IN `_type`      INT, IN `_info` VARCHAR(255), IN `_extfield0` INT,
                                 IN `_extfield1` VARCHAR(255), IN `_extfield2` VARCHAR(255))
  begin
	
	-- 当前时间
	DECLARE currentTime INT DEFAULT UNIX_TIMESTAMP();
	DECLARE _userCoin FLOAT;
	DECLARE _count INT  DEFAULT 0;
	-- select _coin, _fcoin, _liqType, _info;
	IF _coin IS NULL THEN
		SET _coin=0;
	END IF;
	IF _fcoin IS NULL THEN
		SET _fcoin=0;
	END IF;
	-- 更新用户表
	SELECT COUNT(1) INTO _count FROM xy_coin_log WHERE  extfield0=_extfield0  AND info='中奖奖金'  AND `uid`=_uid;
	IF  _count<1 THEN
	UPDATE xy_members SET coin = coin + _coin, fcoin = fcoin + _fcoin WHERE `uid` = _uid;
	SELECT coin INTO _userCoin FROM xy_members WHERE `uid`=_uid;
	-- 添加资金流动日志
	INSERT INTO xy_coin_log(coin, fcoin, userCoin, `uid`, actionTime, liqType, `type`, info, extfield0, extfield1, extfield2) VALUES(_coin, _fcoin, _userCoin, _uid, currentTime, _liqType, _type, _info, _extfield0, _extfield1, _extfield2);
	END IF;
	-- select coin, fcoin from xy_members where `uid`=_uid;

end;
