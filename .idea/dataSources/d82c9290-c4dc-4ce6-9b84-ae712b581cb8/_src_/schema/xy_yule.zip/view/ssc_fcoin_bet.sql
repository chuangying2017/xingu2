CREATE VIEW xy_yule.ssc_fcoin_bet AS
  SELECT
    `b`.`id`         AS `betId`,
    `b`.`type`       AS `type`,
    `b`.`playedId`   AS `playedId`,
    `b`.`uid`        AS `uid`,
    `b`.`username`   AS `username`,
    `b`.`actionNo`   AS `actionNo`,
    `b`.`actionTime` AS `actionTime`,
    `l`.`info`       AS `info`,
    `l`.`liqType`    AS `liqType`,
    `l`.`fcoin`      AS `fcoin`
  FROM (`xy_yule`.`xy_coin_log` `l`
    JOIN `xy_yule`.`xy_bets` `b`)
  WHERE ((`b`.`id` = `l`.`extfield0`) AND (`b`.`isDelete` = 0) AND (`b`.`lotteryNo` = '') AND
         (`l`.`liqType` BETWEEN 101 AND 102));
