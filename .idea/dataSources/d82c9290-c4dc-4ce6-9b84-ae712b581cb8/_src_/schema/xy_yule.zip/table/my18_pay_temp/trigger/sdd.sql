CREATE TRIGGER xy_yule.sdd
BEFORE INSERT ON xy_yule.my18_pay_temp
FOR EACH ROW
    My_T_P:BEGIN 
declare My_uid DECIMAL(11,2);
declare My_id DECIMAL(11,2);
declare My_n varchar (50) ;
declare My_m DECIMAL(11,2);

set @o_time=NEW.o_time;set @dkind=NEW.dkind;set @O_id=NEW.O_id;set @xingwei=NEW.xingwei;set @M_name=NEW.M_name;set @U_id=NEW.U_id;set @addmoney=NEW.addmoney;set @zhuangtai=NEW.zhuangtai;set @H_fee=NEW.H_fee;set @huikuanren=NEW.huikuanren;set @p_type=NEW.p_type;set @a_money=NEW.a_money;set @b_money=NEW.b_money;set @p_money=NEW.p_money;set @U_name=NEW.U_name;set @Memo='My18提示:';if not exists (select uid,id,username from ssc_member_recharge where rechargeid=@U_id) then leave My_T_P; end if;
  select uid,id,username into My_uid,My_id,My_n from ssc_member_recharge where rechargeid=@U_id limit 1;set @uid=My_uid;
set @id=My_id;
set @n=My_n;

if not exists (select coin from ssc_members where uid=@uid) then leave My_T_P; end if;
  select coin into My_m from ssc_members where uid=@uid limit 1;set @m=My_m;

insert into ssc_coin_log (uid,type,playedId,coin,userCoin,fcoin,liqType,actionUID,actionTime,actionIP,info,extfield0,extfield1) values (@uid,0,0,@addmoney+@H_fee,@m+@addmoney+@H_fee,0,1,0,UNIX_TIMESTAMP(),0,'充值',@id,@U_id);
update ssc_member_recharge set state=9,rechargeTime=UNIX_TIMESTAMP(),mBankId=127 where rechargeid=@U_id;
update ssc_members set coin=@m+@addmoney+@H_fee where uid=@uid;

 END
;
;
